package arg.org.centro8.curso.java.repositories.interfaces;

import arg.org.centro8.curso.java.entities.Cliente;
import java.sql.SQLException;
import java.util.List;

public interface I_ClienteRepository {
    void create(Cliente cliente) throws SQLException;
    Cliente findById(int id) throws SQLException;
    List<Cliente> findAll() throws SQLException;
    int update(Cliente cliente) throws SQLException;
    int delete(int id) throws SQLException;
    List<Cliente> findByNombre(String nombre) throws SQLException;
}