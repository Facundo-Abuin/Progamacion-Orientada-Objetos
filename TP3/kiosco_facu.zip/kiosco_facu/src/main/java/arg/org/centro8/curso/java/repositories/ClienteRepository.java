package arg.org.centro8.curso.java.repositories;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import arg.org.centro8.curso.java.entities.Cliente;
import arg.org.centro8.curso.java.repositories.interfaces.I_ClienteRepository;

@Repository
public class ClienteRepository implements I_ClienteRepository {

    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO clientes (nombre, telefono, frecuente) VALUES (?, ?, ?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM clientes WHERE id_cliente = ?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM clientes";
    private static final String SQL_UPDATE =
        "UPDATE clientes SET nombre = ?, telefono = ?, frecuente = ? WHERE id_cliente = ?";
    private static final String SQL_DELETE =
        "DELETE FROM clientes WHERE id_cliente = ?";
    private static final String SQL_FIND_BY_NOMBRE =
        "SELECT * FROM clientes WHERE nombre LIKE ?";

    public ClienteRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Cliente cliente) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getTelefono());
            ps.setBoolean(3, cliente.isFrecuente());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    cliente.setIdCliente(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Cliente findById(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Cliente> findAll() throws SQLException {
        List<Cliente> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public int update(Cliente cliente) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getTelefono());
            ps.setBoolean(3, cliente.isFrecuente());
            ps.setInt(4, cliente.getIdCliente());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }

    @Override
    public List<Cliente> findByNombre(String nombre) throws SQLException {
        List<Cliente> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_NOMBRE)) {
            ps.setString(1, "%" + nombre + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    private Cliente mapRow(ResultSet rs) throws SQLException {
        Cliente c = new Cliente();
        c.setIdCliente(rs.getInt("id_cliente"));
        c.setNombre(rs.getString("nombre"));
        c.setTelefono(rs.getString("telefono"));
        c.setFrecuente(rs.getBoolean("frecuente"));
        return c;
    }
}