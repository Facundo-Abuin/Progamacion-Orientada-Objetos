package arg.org.centro8.curso.java.repositories;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import arg.org.centro8.curso.java.entities.Venta;
import arg.org.centro8.curso.java.enums.ModalidadPago;
import arg.org.centro8.curso.java.repositories.interfaces.I_VentaRepository;

@Repository
public class VentaRepository implements I_VentaRepository {

    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO ventas (id_cliente, fecha_hora, modalidad_pago, precio_final) VALUES (?, ?, ?, ?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM ventas WHERE id_venta = ?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM ventas";
    private static final String SQL_UPDATE =
        "UPDATE ventas SET id_cliente = ?, fecha_hora = ?, modalidad_pago = ?, precio_final = ? WHERE id_venta = ?";
    private static final String SQL_DELETE =
        "DELETE FROM ventas WHERE id_venta = ?";
    private static final String SQL_FIND_BY_CLIENTE_ID =
        "SELECT * FROM ventas WHERE id_cliente = ?";

    public VentaRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Venta venta) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, venta.getIdCliente());
            ps.setObject(2, venta.getFechaHora());
            ps.setString(3, venta.getModalidadPago().name());
            ps.setDouble(4, venta.getPrecioFinal());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    venta.setIdVenta(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Venta findById(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Venta> findAll() throws SQLException {
        List<Venta> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public int update(Venta venta) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setInt(1, venta.getIdCliente());
            ps.setObject(2, venta.getFechaHora());
            ps.setString(3, venta.getModalidadPago().name());
            ps.setDouble(4, venta.getPrecioFinal());
            ps.setInt(5, venta.getIdVenta());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }

    @Override
    public List<Venta> findByClienteId(int idCliente) throws SQLException {
        List<Venta> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_CLIENTE_ID)) {
            ps.setInt(1, idCliente);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    private Venta mapRow(ResultSet rs) throws SQLException {
        Venta v = new Venta();
        v.setIdVenta(rs.getInt("id_venta"));
        v.setIdCliente(rs.getInt("id_cliente"));
        v.setFechaHora(rs.getObject("fecha_hora",LocalDateTime.class));
        v.setModalidadPago(ModalidadPago.valueOf(rs.getString("modalidad_pago")));
        v.setPrecioFinal(rs.getDouble("precio_final"));
        return v;
    }
}