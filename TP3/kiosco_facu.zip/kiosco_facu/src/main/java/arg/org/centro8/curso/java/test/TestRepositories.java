package arg.org.centro8.curso.java.test;

import arg.org.centro8.curso.java.entities.*;
import arg.org.centro8.curso.java.enums.ModalidadPago;
import arg.org.centro8.curso.java.repositories.*;
import arg.org.centro8.curso.java.repositories.interfaces.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.time.LocalDateTime;
import java.util.List;

@SpringBootApplication(scanBasePackages = "arg.org.centro8.curso.java")
public class TestRepositories {
    public static void main(String[] args) {
        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class, args)) {

            I_ClienteRepository clienteRepository = context.getBean(ClienteRepository.class);
            I_CategoriaRepository categoriaRepository = context.getBean(CategoriaRepository.class);
            I_ProductoRepository productoRepository = context.getBean(ProductoRepository.class);
            I_VentaRepository ventaRepository = context.getBean(VentaRepository.class);
            I_DetalleVentaRepository detalleRepository = context.getBean(DetalleVentaRepository.class);

// >>> Test 1: Crear nuevo Cliente
System.out.println("\n>>> Test 1: creando un nuevo Cliente...");
Cliente nuevoCliente = new Cliente(0, "Axl Rose", "1122334455", true);
clienteRepository.create(nuevoCliente);
if(nuevoCliente.getIdCliente() > 0){
    System.out.println(" ## Cliente creado con el ID: " + nuevoCliente.getIdCliente());
    System.out.println(nuevoCliente);
} else {
    System.err.println(" ¡¡ ERROR - No se pudo crear el cliente !!");
}

// >>> Test 2: Buscar Cliente por ID
System.out.println("\n>>> Test 2: buscando Cliente por ID...");
Cliente clienteEncontrado = clienteRepository.findById(nuevoCliente.getIdCliente());
if(clienteEncontrado != null){
    System.out.println(" ## Cliente encontrado: " + clienteEncontrado);
} else {
    System.err.println(" ¡¡ ERROR - No se encontró el cliente !!");
}

// >>> Test 3: Listar todos los Clientes
System.out.println("\n>>> Test 3: Listando todos los clientes...");
List<Cliente> clientes = clienteRepository.findAll();
if(!clientes.isEmpty()){
    System.out.println(" ## Clientes encontrados: " + clientes.size());
    clientes.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron clientes !!");
}

// >>> Test 4: Crear nueva Categoría
System.out.println("\n>>> Test 4: creando una nueva Categoría...");
Categoria nuevaCategoria = new Categoria(0, "Chocolates");
categoriaRepository.create(nuevaCategoria);
if(nuevaCategoria.getIdCategoria() > 0){
    System.out.println(" ## Categoría creada con el ID: " + nuevaCategoria.getIdCategoria());
    System.out.println(nuevaCategoria);
} else {
    System.err.println(" ¡¡ ERROR - No se pudo crear la categoría !!");
}

// >>> Test 5: Buscar Categoría por ID
System.out.println("\n>>> Test 5: buscando Categoría por ID...");
Categoria categoriaEncontrada = categoriaRepository.findById(nuevaCategoria.getIdCategoria());
if(categoriaEncontrada != null){
    System.out.println(" ## Categoría encontrada: " + categoriaEncontrada);
} else {
    System.err.println(" ¡¡ ERROR - No se encontró la categoría !!");
}

// >>> Test 6: Listar todas las Categorías
System.out.println("\n>>> Test 6: Listando todas las categorías...");
List<Categoria> categorias = categoriaRepository.findAll();
if(!categorias.isEmpty()){
    System.out.println(" ## Categorías encontradas: " + categorias.size());
    categorias.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron categorías !!");
}

// >>> Test 7: Crear nuevo Producto
System.out.println("\n>>> Test 7: creando un nuevo Producto...");
Producto nuevoProducto = new Producto(0, "Milka", 400000.0, 15, nuevaCategoria.getIdCategoria());
productoRepository.create(nuevoProducto);
if(nuevoProducto.getIdProducto() > 0){
    System.out.println(" ## Producto creado con el ID: " + nuevoProducto.getIdProducto());
    System.out.println(nuevoProducto);
} else {
    System.err.println(" ¡¡ ERROR - No se pudo crear el producto !!");
}

// >>> Test 8: Buscar Producto por ID
System.out.println("\n>>> Test 8: buscando Producto por ID...");
Producto productoEncontrado = productoRepository.findById(nuevoProducto.getIdProducto());
if(productoEncontrado != null){
    System.out.println(" ## Producto encontrado: " + productoEncontrado);
} else {
    System.err.println(" ¡¡ ERROR - No se encontró el producto !!");
}

// >>> Test 9: Listar todos los Productos
System.out.println("\n>>> Test 9: Listando todos los productos...");
List<Producto> productos = productoRepository.findAll();
if(!productos.isEmpty()){
    System.out.println(" ## Productos encontrados: " + productos.size());
    productos.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron productos !!");
}

// >>> Test 10: Crear nueva Venta
System.out.println("\n>>> Test 10: creando una nueva Venta...");
Venta nuevaVenta = new Venta(0, nuevoCliente.getIdCliente(), LocalDateTime.now(), ModalidadPago.EFECTIVO, 400000.0);
ventaRepository.create(nuevaVenta);
if(nuevaVenta.getIdVenta() > 0){
    System.out.println(" ## Venta creada con el ID: " + nuevaVenta.getIdVenta());
    System.out.println(nuevaVenta);
} else {
    System.err.println(" ¡¡ ERROR - No se pudo crear la venta !!");
}

// >>> Test 11: Buscar Venta por ID
System.out.println("\n>>> Test 11: buscando Venta por ID...");
Venta ventaEncontrada = ventaRepository.findById(nuevaVenta.getIdVenta());
if(ventaEncontrada != null){
    System.out.println(" ## Venta encontrada: " + ventaEncontrada);
} else {
    System.err.println(" ¡¡ ERROR - No se encontró la venta !!");
}

// >>> Test 12: Listar todas las Ventas
System.out.println("\n>>> Test 12: Listando todas las ventas...");
List<Venta> ventas = ventaRepository.findAll();
if(!ventas.isEmpty()){
    System.out.println(" ## Ventas encontradas: " + ventas.size());
    ventas.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron ventas !!");
}

// >>> Test 13: Crear nuevo DetalleVenta
System.out.println("\n>>> Test 13: creando un nuevo Detalle de Venta...");
DetalleVenta nuevoDetalle = new DetalleVenta(nuevaVenta.getIdVenta(), nuevoProducto.getIdProducto(), 1, 400000.0);
detalleRepository.create(nuevoDetalle);
if (nuevoDetalle.getIdVenta() > 0 && nuevoDetalle.getIdProducto() > 0) {
    System.out.println(" ## DetalleVenta creado correctamente:");
    System.out.println(nuevoDetalle);
} else {
    System.err.println(" ¡¡ ERROR - No se pudo crear el DetalleVenta !!");
}

// >>> Test 14: Buscar DetalleVenta por IDs
System.out.println("\n>>> Test 14: buscando DetalleVenta por IDs...");
DetalleVenta detalleEncontrado = detalleRepository.findByIds(nuevoDetalle.getIdVenta(), nuevoDetalle.getIdProducto());
if(detalleEncontrado != null){
    System.out.println(" ## DetalleVenta encontrado: " + detalleEncontrado);
} else {
    System.err.println(" ¡¡ ERROR - No se encontró el detalle de venta !!");
}

// >>> Test 15: Listar todos los Detalles de Venta
System.out.println("\n>>> Test 15: Listando todos los detalles de venta...");
List<DetalleVenta> detalles = detalleRepository.findAll();
if(!detalles.isEmpty()){
    System.out.println(" ## Detalles encontrados: " + detalles.size());
    detalles.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron detalles de venta !!");
}

 } catch (Exception e) {
            System.err.println("¡¡ ERROR durante las pruebas !!");
            e.printStackTrace();
        } finally {
            System.out.println("\n<<< PRUEBAS REDUCIDAS FINALIZADAS >>>");
        }
    }
}