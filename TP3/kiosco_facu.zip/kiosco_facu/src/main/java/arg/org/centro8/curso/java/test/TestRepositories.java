package arg.org.centro8.curso.java.test;

import arg.org.centro8.curso.java.entities.*;
import arg.org.centro8.curso.java.enums.ModalidadPago;
import arg.org.centro8.curso.java.repositories.*;
import arg.org.centro8.curso.java.repositories.interfaces.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.time.LocalDateTime;
import java.util.List;

@SpringBootApplication(scanBasePackages = "arg.org.centro8.curso.java")
public class TestRepositories {
    public static void main(String[] args) {
        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class, args)) {

            I_ClienteRepository clienteRepository = context.getBean(ClienteRepository.class);
            I_CategoriaRepository categoriaRepository = context.getBean(CategoriaRepository.class);
            I_ProductoRepository productoRepository = context.getBean(ProductoRepository.class);
            I_VentaRepository ventaRepository = context.getBean(VentaRepository.class);
            I_DetalleVentaRepository detalleRepository = context.getBean(DetalleVentaRepository.class);

// >>> Test 1: Crear nuevo Cliente
System.out.println("\n>>> Test 1: creando un nuevo Cliente...");
Cliente nuevoCliente = new Cliente(0, "Axl Rose", "746230501", true);
clienteRepository.create(nuevoCliente);
if (nuevoCliente.getIdCliente() > 0) {
    System.out.println(" ## Cliente creado con ID: " + nuevoCliente.getIdCliente());
    System.out.println(nuevoCliente);
} else {
    System.err.println(" ¡¡ ERROR - No se pudo crear el cliente !!");
}

// >>> Test 2: Buscar Cliente por ID
System.out.println("\n>>> Test 2: buscando Cliente por ID...");
Cliente clienteEncontrado = clienteRepository.findById(nuevoCliente.getIdCliente());
if (clienteEncontrado != null) {
    System.out.println(" ## Cliente encontrado: " + clienteEncontrado);
} else {
    System.err.println(" ¡¡ ERROR - No se encontró el cliente !!");
}


// >>> Test 3: Buscar Clientes por nombre
System.out.println("\n>>> Test 3: buscando clientes con nombre 'Axl'...");
List<Cliente> clientesPorNombre = clienteRepository.findByNombre("Axl");
if (!clientesPorNombre.isEmpty()) {
    System.out.println(" ## Clientes encontrados: " + clientesPorNombre.size());
    clientesPorNombre.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron clientes con ese nombre !!");
}

// >>> Test 4: Actualizar Cliente
System.out.println("\n>>> Test 4: actualizando el Cliente " + nuevoCliente.getIdCliente() + "...");
nuevoCliente.setTelefono("937746022");
int filasAfectadasCliente = clienteRepository.update(nuevoCliente);
if (filasAfectadasCliente == 1) {
    System.out.println(" ## Cliente " + nuevoCliente.getIdCliente() + " actualizado correctamente.");
    System.out.println(" ## Verificando actualización: " + clienteRepository.findById(nuevoCliente.getIdCliente()));
} else {
    System.err.println(" ¡¡ ERROR - No se pudo actualizar el cliente !!");
}

// >>> Test 5: Listar todos los Clientes
System.out.println("\n>>> Test 5: listando todos los Clientes...");
List<Cliente> todosLosClientes = clienteRepository.findAll();
if (!todosLosClientes.isEmpty()) {
    System.out.println(" ## Total de clientes: " + todosLosClientes.size());
    todosLosClientes.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron clientes !!");
}

// >>> Test 6: Eliminar Cliente
System.out.println("\n>>> Test 6: eliminando el Cliente " + nuevoCliente.getIdCliente() + "...");
int filasEliminadasCliente = clienteRepository.delete(nuevoCliente.getIdCliente());
if (filasEliminadasCliente == 1) {
    System.out.println(" ## Cliente " + nuevoCliente.getIdCliente() + " eliminado correctamente.");
    System.out.println(" ## Verificando eliminación: " + clienteRepository.findById(nuevoCliente.getIdCliente()));
} else {
    System.err.println(" ¡¡ ERROR - No se pudo eliminar el cliente !!");
}

// >>> Test 7: Crear nueva Categoría
System.out.println("\n>>> Test 7: creando una nueva Categoría...");
Categoria nuevaCategoria = new Categoria(0, "Golosinas");
categoriaRepository.create(nuevaCategoria);
if(nuevaCategoria.getIdCategoria() > 0){
    System.out.println(" ## Categoría creada con el ID: " + nuevaCategoria.getIdCategoria());
    System.out.println(nuevaCategoria);
} else {
    System.err.println(" ¡¡ ERROR - No se pudo crear la categoría !!");
}

// >>> Test 8: Buscar Categoría por ID
System.out.println("\n>>> Test 8: buscando Categoría por ID...");
Categoria categoriaEncontrada = categoriaRepository.findById(nuevaCategoria.getIdCategoria());
if(categoriaEncontrada != null){
    System.out.println(" ## Categoría encontrada: " + categoriaEncontrada);
} else {
    System.err.println(" ¡¡ ERROR - No se encontró la categoría !!");
}

// >>> Test 9: Buscar Categorías por nombre
System.out.println("\n>>> Test 9: buscando Categorías por nombre 'Golo'...");
List<Categoria> categoriasPorNombre = categoriaRepository.findByNombre("Golo");
if(!categoriasPorNombre.isEmpty()){
    System.out.println(" ## Categorías encontradas: " + categoriasPorNombre.size());
    categoriasPorNombre.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron categorías con ese nombre !!");
}

// >>> Test 10: Actualizar Categoría
System.out.println("\n>>> Test 10: actualizando la categoría " + nuevaCategoria.getIdCategoria() + "...");
nuevaCategoria.setNombre("Chocolates");
int filasAfectadasCategoria = categoriaRepository.update(nuevaCategoria);
if (filasAfectadasCategoria == 1) {
    System.out.println(" ## Categoría " + nuevaCategoria.getIdCategoria() + " actualizada correctamente.");
    System.out.println(" ## Verificando actualización: " + categoriaRepository.findById(nuevaCategoria.getIdCategoria()));
} else {
    System.err.println(" ¡¡ ERROR - No se pudo actualizar la categoría !!");
}

// >>> Test 11: Listar todas las Categorías
System.out.println("\n>>> Test 11: Listando todas las categorías...");
List<Categoria> categorias = categoriaRepository.findAll();
if(!categorias.isEmpty()){
    System.out.println(" ## Categorías encontradas: " + categorias.size());
    categorias.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron categorías !!");
}

// >>> Test 12: Eliminar Categoría
System.out.println("\n>>> Test 12: eliminando la categoría " + nuevaCategoria.getIdCategoria() + "...");
int filasEliminadasCategoria = categoriaRepository.delete(nuevaCategoria.getIdCategoria());
if (filasEliminadasCategoria == 1) {
    System.out.println(" ## Categoría " + nuevaCategoria.getIdCategoria() + " eliminada correctamente.");
    System.out.println(" ## Verificando eliminación: " + categoriaRepository.findById(nuevaCategoria.getIdCategoria()));
} else {
    System.err.println(" ¡¡ ERROR - No se pudo eliminar la categoría !!");
}

// >>> Test 13: creando un nuevo Producto...
System.out.println("\n>>> Test 13: creando un nuevo Producto...");
Producto nuevoProducto = new Producto(0, "Milka", 450.0, 20, nuevaCategoria.getIdCategoria());
productoRepository.create(nuevoProducto);
if(nuevoProducto.getIdProducto() > 0){
    System.out.println(" ## Producto creado con el ID: " + nuevoProducto.getIdProducto());
    System.out.println(nuevoProducto);
} else {
    System.err.println(" ¡¡ ERROR - No se pudo crear el producto !!");
}

// >>> Test 14: buscando Producto por ID...
System.out.println("\n>>> Test 14: buscando Producto por ID...");
Producto productoEncontrado = productoRepository.findById(nuevoProducto.getIdProducto());
if(productoEncontrado != null){
    System.out.println(" ## Producto encontrado: " + productoEncontrado);
} else {
    System.err.println(" ¡¡ ERROR - No se encontró el producto !!");
}

// >>> Test 15: Buscando productos por nombre...
System.out.println("\n>>> Test 15: buscando Productos por nombre 'Milka'...");
List<Producto> productosPorNombre = productoRepository.findByNombre("Milka");
if(!productosPorNombre.isEmpty()){
    System.out.println(" ## Productos encontrados: " + productosPorNombre.size());
    productosPorNombre.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron productos con ese nombre !!");
}

// >>> Test 16: actualizando el producto...
System.out.println("\n>>> Test 16: actualizando el producto " + nuevoProducto.getIdProducto() + "...");
nuevoProducto.setPrecio(500.0);
nuevoProducto.setStock(25);
int filasAfectadasProducto = productoRepository.update(nuevoProducto);
if (filasAfectadasProducto == 1) {
    System.out.println(" ## Producto " + nuevoProducto.getIdProducto() + " actualizado correctamente.");
    System.out.println(" ## Verificando actualización: " + productoRepository.findById(nuevoProducto.getIdProducto()));
} else {
    System.err.println(" ¡¡ ERROR - No se pudo actualizar el producto !!");
}

// >>> Test 17: Listando todos los productos...
System.out.println("\n>>> Test 17: Listando todos los productos...");
List<Producto> productos = productoRepository.findAll();
if(!productos.isEmpty()){
    System.out.println(" ## Productos encontrados: " + productos.size());
    productos.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron productos !!");
}

// >>> Test 18: eliminando el producto...
System.out.println("\n>>> Test 18: eliminando el producto " + nuevoProducto.getIdProducto() + "...");
int filasEliminadasProducto = productoRepository.delete(nuevoProducto.getIdProducto());
if (filasEliminadasProducto == 1) {
    System.out.println(" ## Producto " + nuevoProducto.getIdProducto() + " eliminado correctamente.");
    System.out.println(" ## Verificando: " + productoRepository.findById(nuevoProducto.getIdProducto()));
} else {
    System.err.println(" ¡¡ ERROR - No se pudo eliminar el producto !!");
}

// >>> Test 19: creando una nueva Venta...
System.out.println("\n>>> Test 19: creando una nueva Venta...");
Venta nuevaVenta = new Venta(0, nuevoCliente.getIdCliente(), LocalDateTime.now(), ModalidadPago.EFECTIVO, nuevoProducto.getPrecio());
ventaRepository.create(nuevaVenta);
if(nuevaVenta.getIdVenta() > 0){
    System.out.println(" ## Venta creada con el ID: " + nuevaVenta.getIdVenta());
    System.out.println(nuevaVenta);
} else {
    System.err.println(" ¡¡ ERROR - No se pudo crear la venta !!");
}

// >>> Test 20: buscando Venta por ID...
System.out.println("\n>>> Test 20: buscando Venta por ID...");
Venta ventaEncontrada = ventaRepository.findById(nuevaVenta.getIdVenta());
if(ventaEncontrada != null){
    System.out.println(" ## Venta encontrada: " + ventaEncontrada);
} else {
    System.err.println(" ¡¡ ERROR - No se encontró la venta !!");
}

// >>> Test 21: buscando ventas por ID de cliente...
System.out.println("\n>>> Test 21: buscando ventas por ID de cliente...");
List<Venta> ventasCliente = ventaRepository.findByClienteId(nuevoCliente.getIdCliente());
if(!ventasCliente.isEmpty()){
    System.out.println(" ## Ventas encontradas para el cliente: " + ventasCliente.size());
    ventasCliente.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron ventas para ese cliente !!");
}

// >>> Test 22: actualizando la venta...
System.out.println("\n>>> Test 22: actualizando la venta " + nuevaVenta.getIdVenta() + "...");
nuevaVenta.setModalidadPago(ModalidadPago.DEBITO);
nuevaVenta.setPrecioFinal(999.99);
int filasAfectadasVenta = ventaRepository.update(nuevaVenta);
if (filasAfectadasVenta == 1) {
    System.out.println(" ## Venta " + nuevaVenta.getIdVenta() + " actualizada correctamente.");
    System.out.println(" ## Verificando actualización: " + ventaRepository.findById(nuevaVenta.getIdVenta()));
} else {
    System.err.println(" ¡¡ ERROR - No se pudo actualizar la venta !!");
}

// >>> Test 23: Listando todas las ventas...
System.out.println("\n>>> Test 23: Listando todas las ventas...");
List<Venta> ventas = ventaRepository.findAll();
if(!ventas.isEmpty()){
    System.out.println(" ## Ventas encontradas: " + ventas.size());
    ventas.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron ventas !!");
}

// >>> Test 24: eliminando la venta...
System.out.println("\n>>> Test 24: eliminando la venta " + nuevaVenta.getIdVenta() + "...");
int filasEliminadasVenta = ventaRepository.delete(nuevaVenta.getIdVenta());
if (filasEliminadasVenta == 1) {
    System.out.println(" ## Venta " + nuevaVenta.getIdVenta() + " eliminada correctamente.");
    System.out.println(" ## Verificando: " + ventaRepository.findById(nuevaVenta.getIdVenta()));
} else {
    System.err.println(" ¡¡ ERROR - No se pudo eliminar la venta !!");
}

// >>> Test 25: creando un nuevo DetalleVenta...
System.out.println("\n>>> Test 25: creando un nuevo Detalle de Venta...");
DetalleVenta nuevoDetalle = new DetalleVenta(nuevaVenta.getIdVenta(), nuevoProducto.getIdProducto(), 2, nuevoProducto.getPrecio());
detalleRepository.create(nuevoDetalle);
System.out.println(" ## DetalleVenta creado para Venta ID " + nuevoDetalle.getIdVenta() +
                   " y Producto ID " + nuevoDetalle.getIdProducto());
System.out.println(nuevoDetalle);

// >>> Test 26: buscando DetalleVenta por ID...
System.out.println("\n>>> Test 26: buscando DetalleVenta por IDs...");
DetalleVenta detalleEncontrado = detalleRepository.findByIds(nuevoDetalle.getIdVenta(), nuevoDetalle.getIdProducto());
if(detalleEncontrado != null){
    System.out.println(" ## DetalleVenta encontrado: " + detalleEncontrado);
} else {
    System.err.println(" ¡¡ ERROR - No se encontró el detalle de venta !!");
}

// >>> Test 27: buscando detalles por ID de Venta...
System.out.println("\n>>> Test 27: buscando detalles por ID de Venta...");
List<DetalleVenta> detallesVenta = detalleRepository.findByVentaId(nuevaVenta.getIdVenta());
if(!detallesVenta.isEmpty()){
    System.out.println(" ## Detalles encontrados para la venta: " + detallesVenta.size());
    detallesVenta.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron detalles para esa venta !!");
}

// >>> Test 28: actualizando el DetalleVenta...
System.out.println("\n>>> Test 28: actualizando el DetalleVenta...");
nuevoDetalle.setCantidad(3);
nuevoDetalle.setPrecioUnitario(999.99);
int filasAfectadasDetalleVenta = detalleRepository.update(nuevoDetalle);
if (filasAfectadasDetalleVenta == 1) {
    System.out.println(" ## DetalleVenta actualizado correctamente:");
    System.out.println(" ## Verificando actualización: " + detalleRepository.findByIds(nuevoDetalle.getIdVenta(), nuevoDetalle.getIdProducto()));
} else {
    System.err.println(" ¡¡ ERROR - No se pudo actualizar el DetalleVenta !!");
}

// >>> Test 29: Listando todos los DetalleVenta...
System.out.println("\n>>> Test 29: Listando todos los detalles de venta...");
List<DetalleVenta> detalles = detalleRepository.findAll();
if(!detalles.isEmpty()){
    System.out.println(" ## Detalles de venta encontrados: " + detalles.size());
    detalles.forEach(System.out::println);
} else {
    System.err.println(" ¡¡ ERROR - No se encontraron detalles de venta !!");
}

// >>> Test 30: eliminando DetalleVenta...
System.out.println("\n>>> Test 30: eliminando el DetalleVenta...");
int filasEliminadasDetalleVenta = detalleRepository.delete(nuevoDetalle.getIdVenta(), nuevoDetalle.getIdProducto());
if (filasEliminadasDetalleVenta == 1) {
    System.out.println(" ## DetalleVenta eliminado correctamente.");
    DetalleVenta verificacion = detalleRepository.findByIds(nuevoDetalle.getIdVenta(), nuevoDetalle.getIdProducto());
    System.out.println(" ## Verificación: " + (verificacion == null ? "Detalle ya no existe" : verificacion));
} else {
    System.err.println(" ¡¡ ERROR - No se pudo eliminar el DetalleVenta !!");
}

 } catch (Exception e) {
            System.err.println("¡¡ ERROR durante las pruebas !!");
            e.printStackTrace();
        } finally {
            System.out.println("\n<<< PRUEBAS REDUCIDAS FINALIZADAS >>>");
        }
    }
}