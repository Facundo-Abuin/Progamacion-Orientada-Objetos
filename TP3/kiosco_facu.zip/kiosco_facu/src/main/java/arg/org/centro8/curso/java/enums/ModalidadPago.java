package arg.org.centro8.curso.java.enums;

public enum ModalidadPago {
    EFECTIVO,
    DEBITO,
    CREDITO,
    TRANSFERENCIA,
    QR
}
