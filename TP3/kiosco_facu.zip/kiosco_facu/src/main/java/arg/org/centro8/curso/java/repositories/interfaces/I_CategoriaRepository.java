package arg.org.centro8.curso.java.repositories.interfaces;

import arg.org.centro8.curso.java.entities.Categoria;
import java.sql.SQLException;
import java.util.List;

public interface I_CategoriaRepository {
    void create(Categoria categoria) throws SQLException;
    Categoria findById(int id) throws SQLException;
    List<Categoria> findAll() throws SQLException;
    int update(Categoria categoria) throws SQLException;
    int delete(int id) throws SQLException;
    List<Categoria> findByNombre(String nombre) throws SQLException;
}