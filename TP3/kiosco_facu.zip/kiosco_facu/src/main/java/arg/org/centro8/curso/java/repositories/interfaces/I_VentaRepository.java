package arg.org.centro8.curso.java.repositories.interfaces;

import arg.org.centro8.curso.java.entities.Venta;
import java.sql.SQLException;
import java.util.List;

public interface I_VentaRepository {
    void create(Venta venta) throws SQLException;
    Venta findById(int id) throws SQLException;
    List<Venta> findAll() throws SQLException;
    int update(Venta venta) throws SQLException;
    int delete(int id) throws SQLException;
    List<Venta> findByClienteId(int idCliente) throws SQLException;
}