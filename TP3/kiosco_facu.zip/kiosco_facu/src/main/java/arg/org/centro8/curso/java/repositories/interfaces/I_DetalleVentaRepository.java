package arg.org.centro8.curso.java.repositories.interfaces;

import arg.org.centro8.curso.java.entities.DetalleVenta;
import java.sql.SQLException;
import java.util.List;

public interface I_DetalleVentaRepository {
    void create(DetalleVenta dv) throws SQLException;
    DetalleVenta findByIds(int idVenta, int idProducto) throws SQLException;
    List<DetalleVenta> findAll() throws SQLException;
    int update(DetalleVenta dv) throws SQLException;
    int delete(int idVenta, int idProducto) throws SQLException;
    List<DetalleVenta> findByVentaId(int idVenta) throws SQLException;
}
