package arg.org.centro8.curso.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KioscoFacuApplication {

	public static void main(String[] args) {
		SpringApplication.run(KioscoFacuApplication.class, args);
	}

}
