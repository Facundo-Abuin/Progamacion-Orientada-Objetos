package arg.org.centro8.curso.java.repositories.interfaces;

import arg.org.centro8.curso.java.entities.Producto;
import java.sql.SQLException;
import java.util.List;

public interface I_ProductoRepository {
    void create(Producto producto) throws SQLException;
    Producto findById(int id) throws SQLException;
    List<Producto> findAll() throws SQLException;
    int update(Producto producto) throws SQLException;
    int delete(int id) throws SQLException;
    List<Producto> findByNombre(String nombre) throws SQLException;
}
