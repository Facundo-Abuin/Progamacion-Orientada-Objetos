package arg.org.centro8.curso.java.repositories;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import arg.org.centro8.curso.java.entities.DetalleVenta;
import arg.org.centro8.curso.java.repositories.interfaces.I_DetalleVentaRepository;

@Repository
public class DetalleVentaRepository implements I_DetalleVentaRepository {

    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO detalle_ventas (id_venta, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
    private static final String SQL_FIND_BY_IDS =
        "SELECT * FROM detalle_ventas WHERE id_venta = ? AND id_producto = ?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM detalle_ventas";
    private static final String SQL_UPDATE =
        "UPDATE detalle_ventas SET cantidad = ?, precio_unitario = ? WHERE id_venta = ? AND id_producto = ?";
    private static final String SQL_DELETE =
        "DELETE FROM detalle_ventas WHERE id_venta = ? AND id_producto = ?";
    private static final String SQL_FIND_BY_VENTA_ID =
        "SELECT * FROM detalle_ventas WHERE id_venta = ?";

    public DetalleVentaRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(DetalleVenta dv) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE)) {
            ps.setInt(1, dv.getIdVenta());
            ps.setInt(2, dv.getIdProducto());
            ps.setInt(3, dv.getCantidad());
            ps.setDouble(4, dv.getPrecioUnitario());
            ps.executeUpdate();
        }
    }

    @Override
    public DetalleVenta findByIds(int idVenta, int idProducto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_IDS)) {
            ps.setInt(1, idVenta);
            ps.setInt(2, idProducto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<DetalleVenta> findAll() throws SQLException {
        List<DetalleVenta> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public int update(DetalleVenta dv) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setInt(1, dv.getCantidad());
            ps.setDouble(2, dv.getPrecioUnitario());
            ps.setInt(3, dv.getIdVenta());
            ps.setInt(4, dv.getIdProducto());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int idVenta, int idProducto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, idVenta);
            ps.setInt(2, idProducto);
            return ps.executeUpdate();
        }
    }

    @Override
    public List<DetalleVenta> findByVentaId(int idVenta) throws SQLException {
        List<DetalleVenta> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_VENTA_ID)) {
            ps.setInt(1, idVenta);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    private DetalleVenta mapRow(ResultSet rs) throws SQLException {
        DetalleVenta dv = new DetalleVenta();
        dv.setIdVenta(rs.getInt("id_venta"));
        dv.setIdProducto(rs.getInt("id_producto"));
        dv.setCantidad(rs.getInt("cantidad"));
        dv.setPrecioUnitario(rs.getDouble("precio_unitario"));
        return dv;
    }
}