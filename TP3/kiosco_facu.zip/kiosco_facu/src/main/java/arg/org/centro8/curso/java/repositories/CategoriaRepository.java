package arg.org.centro8.curso.java.repositories;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import arg.org.centro8.curso.java.entities.Categoria;
import arg.org.centro8.curso.java.repositories.interfaces.I_CategoriaRepository;

@Repository
public class CategoriaRepository implements I_CategoriaRepository {

    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO categorias (nombre) VALUES (?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM categorias WHERE id_categoria = ?";
    private static final String SQL_FIND_ALL =
        "SELECT * FROM categorias";
    private static final String SQL_UPDATE =
        "UPDATE categorias SET nombre = ? WHERE id_categoria = ?";
    private static final String SQL_DELETE =
        "DELETE FROM categorias WHERE id_categoria = ?";
    private static final String SQL_FIND_BY_NOMBRE =
        "SELECT * FROM categorias WHERE nombre LIKE ?";

    public CategoriaRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Categoria categoria) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, categoria.getNombre());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    categoria.setIdCategoria(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Categoria findById(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Categoria> findAll() throws SQLException {
        List<Categoria> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public int update(Categoria categoria) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, categoria.getNombre());
            ps.setInt(2, categoria.getIdCategoria());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }

    @Override
    public List<Categoria> findByNombre(String nombre) throws SQLException {
        List<Categoria> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_NOMBRE)) {
            ps.setString(1, "%" + nombre + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    private Categoria mapRow(ResultSet rs) throws SQLException {
        Categoria categoria = new Categoria();
        categoria.setIdCategoria(rs.getInt("id_categoria"));
        categoria.setNombre(rs.getString("nombre"));
        return categoria;
    }
}