-- Productos con el mayor stock disponible

select id_producto, nombre, stock
from productos
where stock = (select max(stock) from productos);

-- Clientes que realizaron más de una compra

select
c.id_cliente, c.nombre,
count(v.id_venta) as cantidad_compras
from clientes c
join ventas v on c.id_cliente = v.id_cliente
group by c.id_cliente, c.nombre
having count(v.id_venta) > 1;

-- Total gastado por cada cliente

select c.nombre, sum(v.precio_final) as total_gastado
from clientes c
join ventas v on c.id_cliente = v.id_cliente
group by c.nombre;

-- Productos más vendidos (por cantidad)

select p.nombre, sum(dv.cantidad) as total_vendidos
from productos p
join detalle_ventas dv on p.id_producto = dv.id_producto
group by p.nombre
order by total_vendidos desc;

-- Cantidad de ventas por forma de pago

select modalidad_pago, count(*) as cantidad_ventas
from ventas
group by modalidad_pago;