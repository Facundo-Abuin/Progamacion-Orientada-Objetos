insert into clientes (nombre, telefono, frecuente) values
('Juan Pérez', '1132456789', true),
('Ana Gómez', '1123456780', false),
('Carlos López', null, false),
('Lucía Fernández', '1147896523', true),
('Mario Ruiz', '1165412378', false);

insert into categorias (nombre) values
('Bebidas'),
('Snacks'),
('Golosinas');

insert into productos (nombre, precio, stock, id_categoria) values
('Coca Cola 500ml', 350.00, 50, 1),
('Pepsi 1L', 450.00, 30, 1),
('Papas Lays', 300.00, 20, 2),
('Alfajor Jorgito', 180.00, 40, 3),
('Chicles Beldent', 150.00, 60, 3),
('Agua Villavicencio 500ml', 250.00, 40, 1),
('Galletitas Oreo', 280.00, 35, 2);

insert into ventas (id_cliente, fecha_hora, modalidad_pago, precio_final) values
(1, '2025-06-16 10:30:00', 'efectivo', 530.00),
(2, '2025-06-16 13:15:00', 'debito', 180.00),
(1, '2025-06-17 09:45:00', 'qr', 750.00),
(4, '2025-06-18 11:10:00', 'transferencia', 500.00);

insert into detalle_ventas (id_venta, id_producto, cantidad, precio_unitario) values
(1, 1, 1, 350.00),
(1, 4, 1, 180.00),
(2, 4, 1, 180.00),
(3, 2, 1, 450.00),
(3, 3, 1, 300.00),
(4, 6, 2, 250.00);