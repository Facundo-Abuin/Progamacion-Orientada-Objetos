package arg.org.centro8.curso.java.entities;

import java.time.LocalDateTime;

import arg.org.centro8.curso.java.enums.ModalidadPago;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Venta {
    private int idVenta;
    private int idCliente;
    private LocalDateTime fechaHora;
    private ModalidadPago modalidadPago;
    private double precioFinal;
}
