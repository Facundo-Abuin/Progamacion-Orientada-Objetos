drop database if exists kiosco_facu;
create database if not exists kiosco_facu;
use kiosco_facu;

create table clientes (
id_cliente int primary key auto_increment,
nombre varchar(50) not null,
telefono varchar(20),
frecuente boolean not null default false
);

create table categorias (
id_categoria int primary key auto_increment,
nombre varchar(50) not null
);

create table productos (
id_producto int primary key auto_increment,
nombre varchar(50) not null,
precio decimal(10,2) not null,
stock int not null,
id_categoria int not null,
foreign key (id_categoria) references categorias(id_categoria)
);

create table ventas (
id_venta int primary key auto_increment,
id_cliente int not null,
fecha_hora datetime not null,
modalidad_pago enum('efectivo', 'debito', 'credito', 'transferencia', 'qr') not null,
precio_final decimal(10,2) not null,
foreign key (id_cliente) references clientes(id_cliente)
);

create table detalle_ventas (
id_venta int,
id_producto int,
cantidad int not null,
precio_unitario decimal(10,2) not null,
foreign key (id_venta) references ventas(id_venta),
foreign key (id_producto) references productos(id_producto),
primary key (id_venta, id_producto)
);