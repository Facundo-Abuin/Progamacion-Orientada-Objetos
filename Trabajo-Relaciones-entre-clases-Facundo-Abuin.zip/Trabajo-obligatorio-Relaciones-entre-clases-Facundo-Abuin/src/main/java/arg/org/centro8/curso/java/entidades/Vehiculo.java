package arg.org.centro8.curso.java.entidades;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public abstract class Vehiculo {

    private String marca;
    private String modelo;
    private String color;
    private Double precio; // Puede ser null
    @Setter(AccessLevel.NONE)
    private Radio radio;

    public Vehiculo(String marca, String modelo, String color, Double precio, Radio radio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;

        if (radio != null) {
            if (radio.getVehiculoActual() != null) {
                System.out.println("Advertencia: esta radio ya está en uso. No se asignará.");
            } else {
                this.radio = radio;
                radio.setVehiculoActual(this);
            }
        }
    }

    public abstract String tipoDeVehiculo();

    /**
     * Asigna una radio al vehículo si no tiene una y la radio no está en uso.
     *
     * @param radio la radio que se desea agregar
     */

    public void agregarRadio(Radio radio) {
        if (radio == null) {
            System.out.println("Error: no se puede agregar una radio nula.");
            return;
        }
        if (this.radio != null) {
            System.out.println("Advertencia: este vehículo ya tiene una radio. Use cambiarRadio si desea reemplazarla.");
            return;
        }
        if (radio.getVehiculoActual() != null) {
            System.out.println("Error: esta radio ya está instalada en otro vehículo.");
            return;
        }
        this.radio = radio;
        radio.setVehiculoActual(this);
    }

     /**
     * Cambia la radio actual del vehículo por una nueva, siempre que no esté en uso por otro vehículo.
     *
     * @param nuevaRadio la nueva radio que se desea asignar al vehículo
     */

    public void cambiarRadio(Radio nuevaRadio) {
        if (nuevaRadio == null) {
            System.out.println("Error: no se puede cambiar a una radio nula.");
            return;
        }
        if (nuevaRadio.getVehiculoActual() != null) {
            System.out.println("Error: esta radio ya está instalada en otro vehículo.");
            return;
        }
        if (this.radio != null) {
            this.radio.setVehiculoActual(null);  // Libera la anterior
        }
        this.radio = nuevaRadio;
        nuevaRadio.setVehiculoActual(this);
    }
}