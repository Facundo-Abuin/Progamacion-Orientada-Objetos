package arg.org.centro8.curso.java.entidades;

import lombok.ToString;

@ToString(callSuper = true)
public class AutoClasico extends Vehiculo {

    public AutoClasico(String marca, String modelo, String color, Double precio) {
        super(marca, modelo, color, precio, null);
    }

    // Método que devuelve el tipo de vehículo como un String.
    @Override
    public String tipoDeVehiculo() {
        return "Auto Clasico";
    }
}
