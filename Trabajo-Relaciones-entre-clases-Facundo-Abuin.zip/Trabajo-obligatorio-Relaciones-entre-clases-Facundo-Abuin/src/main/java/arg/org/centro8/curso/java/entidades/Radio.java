package arg.org.centro8.curso.java.entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(exclude = "vehiculoActual")
public class Radio {

    private String marca;
    private int potencia;
    private Vehiculo vehiculoActual;

    public Radio(String marca, int potencia) {
        if (marca == null || marca.isEmpty()) {
            System.out.println("Advertencia: la marca de la radio está vacía.");
        }
        if (potencia <= 0) {
            System.out.println("Advertencia: la potencia debe ser mayor que cero.");
        }
        this.marca = marca;
        this.potencia = potencia;
        this.vehiculoActual = null;
    }

    /**
     * Verifica si la radio está siendo utilizada por algún vehículo.
     * Muestra un mensaje por consola indicando el estado.
     */
    
    public void verificarUso() {
        if (vehiculoActual != null) {
            System.out.println("La radio está en uso por un vehículo.");
        } else {
            System.out.println("La radio no está en uso.");
        }
    }
}


