package arg.org.centro8.curso.java.entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(exclude = "vehiculoActual")
public class Radio {

    private String marca;
    private int potencia;
    private Vehiculo vehiculoActual;

    public Radio(String marca, int potencia) {
        if (marca == null || marca.isEmpty())
            throw new IllegalArgumentException("La marca de la radio no puede estar vacía.");
        if (potencia <= 0)
            throw new IllegalArgumentException("La potencia debe ser mayor que cero.");

        this.marca = marca;
        this.potencia = potencia;
        this.vehiculoActual = null;
    }

    /**
     * Verifica si la radio está siendo utilizada por algún vehículo.
     * Muestra un mensaje por consola indicando el estado.
     */
    
    public void verificarUso() {
        if (vehiculoActual != null) {
            System.out.println("La radio está en uso por un vehículo.");
        } else {
            System.out.println("La radio no está en uso.");
        }
    }
}


