package arg.org.centro8.curso.java.test;

import arg.org.centro8.curso.java.entidades.AutoClasico;
import arg.org.centro8.curso.java.entidades.AutoNuevo;
import arg.org.centro8.curso.java.entidades.Colectivo;
import arg.org.centro8.curso.java.entidades.Radio;

public class TestEntidades {
    public static void main(String[] args) {
        // Radios
        Radio radio1 = new Radio("Sony", 200);
        Radio radio2 = new Radio("Pioneer", 300);
        Radio radio3 = new Radio("Kenwood", 250);

        // Información de las radios
        System.out.println("Radio 1: " + radio1);
        System.out.println("Radio 2: " + radio2);
        System.out.println("Radio 3: " + radio3);

        // Creando vehículos
        AutoClasico auto1 = new AutoClasico("Ford", "Falcon", "Verde", 50000.0);
        System.out.println(auto1);
        AutoNuevo auto2 = new AutoNuevo("Toyota", "Corolla", "Blanco", 25000.0, radio1);
        System.out.println(auto2);
        Colectivo auto3 = new Colectivo("Mercedes", "Sprinter", "Amarillo", 80000.0);
        System.out.println(auto3);

        // Mostrar tipo de vehículos
        System.out.println("Tipo de vehículo: " + auto1.tipoDeVehiculo());
        System.out.println("Tipo de vehículo: " + auto2.tipoDeVehiculo());
        System.out.println("Tipo de vehículo: " + auto3.tipoDeVehiculo());

        //Agregar radio a Auto Clásico
        auto1.agregarRadio(radio2);
        System.out.println("Auto Clásico ahora tiene la radio: " + auto1.getRadio());
        System.out.println(auto1);

        //Agregar radio a Colectivo
        auto3.agregarRadio(radio3);
        System.out.println("Colectivo ahora tiene la radio: " + auto3.getRadio());
        System.out.println(auto3);

        //Cambiar la Radio del Colectivo
        Radio radio4 = new Radio("Philips", 180);
        auto3.cambiarRadio(radio4);
        System.out.println("Colectivo ahora tiene la nueva radio: " + auto3.getRadio());
        System.out.println(auto3);

        // Intentar agregar una radio ya en uso
        //auto1.agregarRadio(radio1);
        //System.out.println(auto1);

        // Intentar cambiar a una radio ya en uso
        //auto3.cambiarRadio(radio1);
        //System.out.println(auto3);

        // Intentar agregar una radio nula
        //auto1.agregarRadio(null);
        //System.out.println(auto1);

        // Intentar cambiar a una radio nula
        //auto3.cambiarRadio(null);
        //System.out.println(auto3);
    }
}