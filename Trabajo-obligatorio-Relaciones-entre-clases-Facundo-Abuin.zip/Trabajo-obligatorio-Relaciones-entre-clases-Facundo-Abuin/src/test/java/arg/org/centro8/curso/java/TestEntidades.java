package arg.org.centro8.curso.java;

import arg.org.centro8.curso.java.entidades.*;

public class TestEntidades {
    public static void main(String[] args) {
        System.out.println("Creación de Radios");
        Radio radio1 = new Radio("Sony", 200);
        Radio radio2 = new Radio("Pioneer", 300);
        Radio radio3 = new Radio("Kenwood", 250);
        
        // Información de las radios
        System.out.println("Radio 1: " + radio1.getMarca() + " con potencia " + radio1.getPotencia() + "W");
        System.out.println("Radio 2: " + radio2.getMarca() + " con potencia " + radio2.getPotencia() + "W");
        System.out.println("Radio 3: " + radio3.getMarca() + " con potencia " + radio3.getPotencia() + "W");

        System.out.println("\nCreación de Vehículos");

        // Creando vehículos
        AutoClasico autoClasico = new AutoClasico("Ford", "Falcon", "Verde", 50000.0);
        AutoNuevo autoNuevo = new AutoNuevo("Toyota", "Corolla", "Blanco", 25000.0, radio1);
        Colectivo colectivo = new Colectivo("Mercedes", "Sprinter", "Amarillo", 80000.0);

        // Mostrar tipo de vehículos
        System.out.println("Tipo de vehículo: " + autoClasico.tipoDeVehiculo());
        System.out.println("Tipo de vehículo: " + autoNuevo.tipoDeVehiculo());
        System.out.println("Tipo de vehículo: " + colectivo.tipoDeVehiculo());

        System.out.println("\nAgregando Radio al Auto Clásico");
        autoClasico.agregarRadio(radio2);
        System.out.println("Auto Clásico ahora tiene la radio: " + autoClasico.getRadio().getMarca() + " con potencia " + autoClasico.getRadio().getPotencia() + "W");

        System.out.println("\nColectivo agregando una Radio");
        colectivo.agregarRadio(radio3);
        System.out.println("Colectivo ahora tiene la radio: " + colectivo.getRadio().getMarca() + " con potencia " + colectivo.getRadio().getPotencia() + "W");
        System.out.println("\nCambiando la Radio del Colectivo");
        Radio radioPhilips = new Radio("Philips", 180);
        colectivo.cambiarRadio(radioPhilips);
        System.out.println("Colectivo ahora tiene la nueva radio: " + colectivo.getRadio().getMarca() + " con potencia " + colectivo.getRadio().getPotencia() + "W");
    }
}