package arg.org.centro8.curso.java.entidades;

public final class Colectivo extends Vehiculo {

    public Colectivo(String marca, String modelo, String color, Double precio) {
        super(marca, modelo, color, precio, null); // puede crearse sin radio
    }

    @Override
    public String tipoDeVehiculo() {
        return "Colectivo";
    }
}
