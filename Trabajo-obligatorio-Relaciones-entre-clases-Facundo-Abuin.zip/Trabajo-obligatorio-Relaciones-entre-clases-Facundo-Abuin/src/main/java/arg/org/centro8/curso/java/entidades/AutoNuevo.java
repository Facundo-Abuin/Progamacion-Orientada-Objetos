package arg.org.centro8.curso.java.entidades;

public class AutoNuevo extends Vehiculo {
    public AutoNuevo(String marca, String modelo, String color, Double precio, Radio radio) {  
        super(marca, modelo, color, precio, radio); // esta vez pasamos una radio real
        if (radio == null) {
            throw new IllegalArgumentException("Un Auto Nuevo debe tener una radio al ser creado.");
        }
    }

    @Override
    public String tipoDeVehiculo() {
        return "Auto Nuevo";
    }
}
