package arg.org.centro8.curso.java.entidades;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public abstract class Vehiculo {

    private String marca;
    private String modelo;
    private String color;
    private Double precio;
    @Setter(AccessLevel.NONE)
    private Radio radio;

   

    public abstract String tipoDeVehiculo();

     // Método para validar la radio después de construir el objeto
    public void inicializarRadio() {
        if (radio != null) {
            if (radio.getVehiculoActual() != null) {
                throw new IllegalStateException("Esta Radio ya está instalada en otro vehículo.");
            }
            radio.setVehiculoActual(this);
        }
    }

    public void agregarRadio(Radio radio) {
        if (radio == null) throw new IllegalArgumentException("No se puede agregar una radio nula.");
        if (radio.getVehiculoActual() != null) {
            throw new IllegalStateException("Esta Radio ya está instalada en otro vehículo.");
        }
        this.radio = radio;
        radio.setVehiculoActual(this);
    }

    public void cambiarRadio(Radio nuevaRadio) {
        if (nuevaRadio == null) throw new IllegalArgumentException("No se puede cambiar a una radio nula.");
        if (nuevaRadio.getVehiculoActual() != null) {
            throw new IllegalStateException("Esta Radio ya está instalada en otro vehículo.");
        }
        if (this.radio != null) {
            this.radio.setVehiculoActual(null);  // Liberar la radio anterior
        }
        this.radio = nuevaRadio;
        nuevaRadio.setVehiculoActual(this);
    }
}