package arg.org.centro8.curso.java.entidades;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Radio {
    private String marca;
    private int potencia;
    private Vehiculo vehiculoActual; // Indica si esta radio ya está en uso

    public Radio(String marca, int potencia) {
        if (marca == null || marca.isEmpty()) {
            throw new IllegalArgumentException("La marca de la radio no puede ser nula o vacía.");
        }
        if (potencia <= 0) {
            throw new IllegalArgumentException("La potencia debe ser mayor que cero.");
        }
        this.marca = marca;
        this.potencia = potencia;
        this.vehiculoActual = null; // Inicialmente, no pertenece a ningún vehículo
    }

    // Método para verificar si la radio está en uso
    public void verificarUso() {
        if (vehiculoActual != null) {
            System.out.println("La radio está en uso.");
        } else {
            System.out.println("La radio no está en uso.");
        }
    }
}


