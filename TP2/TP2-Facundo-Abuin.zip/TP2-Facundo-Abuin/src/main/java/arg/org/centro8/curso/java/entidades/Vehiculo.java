package arg.org.centro8.curso.java.entidades;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class Vehiculo implements Comparable<Vehiculo> {
    private String marca;
    private String modelo;
    private double precio;

    // Constructor para inicializar los atributos
    public Vehiculo(String marca, String modelo, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    //Implementación del método compareTo para ordenar por precio (de menor a mayor)
    @Override
    public int compareTo(Vehiculo otro) {
        return Double.compare(this.precio, otro.precio);
    }

    @Override
    public abstract String toString();
}
