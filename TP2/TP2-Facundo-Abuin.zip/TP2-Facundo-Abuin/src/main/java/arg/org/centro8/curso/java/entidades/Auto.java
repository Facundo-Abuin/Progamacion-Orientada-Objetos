package arg.org.centro8.curso.java.entidades;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Auto extends Vehiculo {
    private int puertas;

    // Constructor que inicializa los atributos heredados y el propio
    public Auto(String marca, String modelo, double precio, int puertas) {
        super(marca, modelo, precio); // llama al constructor de Vehiculo
        this.puertas = puertas;
    }

    // Sobrescribe el método toString para mostrar los datos del auto con el formato solicitado
    @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // Puertas: %d // Precio: $%,.2f",
                getMarca(), getModelo(), puertas, getPrecio());
    }
}
