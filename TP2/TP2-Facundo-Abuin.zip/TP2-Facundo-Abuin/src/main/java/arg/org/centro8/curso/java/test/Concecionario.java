package arg.org.centro8.curso.java.test;

import arg.org.centro8.curso.java.entidades.VehicleService;

public class Concecionario{
    public static void main(String[] args) {
        VehicleService service = new VehicleService();
        service.ejecutarProceso();
    }
}
