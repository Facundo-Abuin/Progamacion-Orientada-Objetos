package arg.org.centro8.curso.java.entidades;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Moto extends Vehiculo {
    private String cilindrada;

    // Constructor que inicializa los atributos heredados y el propio
    public Moto(String marca, String modelo, double precio, String cilindrada) {
        super(marca, modelo, precio); // llama al constructor de Vehiculo
        this.cilindrada = cilindrada;
    }

    // Sobrescribe el método toString para mostrar los datos de la moto con el formato solicitado
    @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // Cilindrada: %sc // Precio: $%,.2f",
                getMarca(), getModelo(), cilindrada, getPrecio());
    }
}
