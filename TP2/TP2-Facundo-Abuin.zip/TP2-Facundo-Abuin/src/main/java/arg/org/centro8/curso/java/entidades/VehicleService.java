package arg.org.centro8.curso.java.entidades;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class VehicleService {
    private final List<Vehiculo> vehiculos = new ArrayList<>();

    public VehicleService() {
        cargarVehiculos();
    }

    private void cargarVehiculos() {
        vehiculos.add(new Auto("Peugeot", "206", 200000.00, 4));
        vehiculos.add(new Moto("Honda", "Titan", 60000.00, "125"));
        vehiculos.add(new Auto("Peugeot", "208", 250000.00, 5));
        vehiculos.add(new Moto("Yamaha", "YBR", 80500.50, "160"));
    }

    // Encuentra el vehículo más caro
    private Vehiculo obtenerVehiculoMasCaro() {
        return vehiculos.stream()
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .orElse(null);
    }

    // Encuentra el vehículo más barato
    private Vehiculo obtenerVehiculoMasBarato() {
        return vehiculos.stream()
                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                .orElse(null);
    }

    // Filtra el primer vehículo que contenga la letra solicitada
    private Vehiculo filtrarPorLetra(String letra) {
        return vehiculos.stream()
                .filter(v -> v.getModelo().contains(letra))
                .findFirst()
                .orElse(null);
    }

    // Ordena por orden natural (compareTo)
    private List<Vehiculo> ordenarVehiculos() {
        return vehiculos.stream()
                .sorted()
                .toList();
    }

    // Ejecuta todo el proceso y muestra los resultados
    public void ejecutarProceso() {
        vehiculos.forEach(System.out::println);
        System.out.println("\n==============================\n");

        Vehiculo masCaro = obtenerVehiculoMasCaro();
        Vehiculo masBarato = obtenerVehiculoMasBarato();
        Vehiculo conLetraY = filtrarPorLetra("Y");

        System.out.println("Vehículo más caro: " + masCaro.getMarca() + " " + masCaro.getModelo());
        System.out.println("Vehículo más barato: " + masBarato.getMarca() + " " + masBarato.getModelo());
        System.out.println("Vehículo que contiene la letra solicitada 'Y': " +
                conLetraY.getMarca() + " " + conLetraY.getModelo() + " $" + String.format("%,.2f", conLetraY.getPrecio()));

        System.out.println("\n==============================\n");

        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
        ordenarVehiculos().forEach(System.out::println);
    }
}
