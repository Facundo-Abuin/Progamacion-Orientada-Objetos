package arg.org.centro8.curso.java.entidades;

import lombok.ToString;

@ToString(callSuper = true)
public class AutoNuevo extends Vehiculo {
    public AutoNuevo(String marca, String modelo, String color, Double precio, Radio radio) {  
        super(marca, modelo, color, precio, radio);
        if (radio == null) {
            throw new IllegalArgumentException("Un Auto Nuevo debe tener una radio al ser creado.");
        }
    }

    // Método que devuelve el tipo de vehículo como un String.
    @Override
    public String tipoDeVehiculo() {
        return "Auto Nuevo";
    }
}
