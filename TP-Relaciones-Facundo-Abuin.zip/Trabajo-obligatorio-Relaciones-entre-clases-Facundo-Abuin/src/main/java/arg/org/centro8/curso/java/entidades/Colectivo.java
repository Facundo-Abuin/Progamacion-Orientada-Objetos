package arg.org.centro8.curso.java.entidades;

import lombok.ToString;

@ToString(callSuper = true)
public final class Colectivo extends Vehiculo { //La clase está declarada como final para evitar que se creen subclases de Colectivo.

    public Colectivo(String marca, String modelo, String color, Double precio) {
        super(marca, modelo, color, precio, null); // puede crearse sin radio
    }

    // Método que devuelve el tipo de vehículo como un String.
    @Override
    public String tipoDeVehiculo() {
        return "Colectivo";
    }
}
